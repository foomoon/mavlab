% Reads 'AVL_input.txt', and 57 foil .dat sections

% Updates data from 'AVL_input.txt' into 'avcaaf.avl'
% Updates N_chord_panels and N_span_panels in 'avcaaf.avl'

% Returns CL, CD, and roll_rate, and writes out the 'forces.txt' file

function [CL,CD,roll_rate] = AVL_sim(velocity,AOA,N_chord_panels,N_span_panels)

% Load wing geometry file
load AVL_input.txt -ascii;
% Load AVL geometry file
avldata = readavlfile('avcaaf.avl');
% Update values of AVL geometry with new wing geometry
for i = 1:57
    avldata{4}{i+4}{2}{1} = AVL_input(i,:);
end

% Set new values for chord/span vortex lattice panels
avldata{4}{2}{2} = [N_chord_panels, 0, N_span_panels, 0];

% Specify new run parameters
[rundata, controls] = initialize_rundata;
rundata.alpha = AOA;
rundata.velocity = velocity;

% Write new avcaaf.run, with angle of attack and velocity parameters
writerunfile('avcaaf.run', rundata, controls, 1);
% Write new avcaaf.avl geometry file
writeavlfile('avcaaf.avl',avldata);

% Run AVLab from MATLAB command prompt
!avlab.bat

% Read control derivative output
[deriv_data, deriv_control] = readddfile('avcaaf_derivs.txt');
% Extract simulation results
CL = deriv_data.cltot;
CD = deriv_data.cdtot;
roll_rate = deriv_data.pb2v;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Run Data Initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [rundata, controls] = initialize_rundata;
 % initialize run case data, since the simulation is doing the iteration
 % we are only interested in starting values
 rundata = struct (...
    'alpha',      6, ...       % angle of attack
    'beta',       0, ...       % angle of sideslip
    'pb2V',       0, ...       % nondimensionalised roll rate
    'qc2V',       0, ...       % nondimensionalised pitch rate
    'rb2V',       0, ...       % nondimensionalized yaw rate
    'CL',         0, ...       % coefficient of lift
    'CDo',        0, ...       % zero lift (form) drag coefficient
    'bank',       0, ...       % bank (level = 0, right wing up is positive)
    'elevation',  0, ...       % elevation via attitude (horizontal = 0)
    'heading',    0, ...       % compass heading (East = 0)
    'Mach',       0, ...       % mach number
    'velocity',   15, ...       % ground velocity
    'density',    1.225, ...% density of air
    'gravacc',    9.81, ...    % acceleration due to gravity
    'turn_rad',   0, ...       % turning radius
    'load_fac',   1, ...       % load factor
    'X_cg',       0.12, ...     % center of gravity ahead of geometry center
    'Y_cg',       0, ...       % center of gravity right of geometry center
    'Z_cg',       0, ...       % center of gravity below geometry center
    'mass',       0.5, ...     % mass of aircraft
    'Ixx',        0.0014, ...% moment of inertia xx-plane
    'Iyy',        0.0079, ...% moment of inertia yy-plane
    'Ixy',        0, ...       % moment of inertia xy-plane
    'Iyz',        0, ...       % moment of inertia yz-plane
    'Izx',        0, ...       % moment of inertia zx-plane
    'viscCL_a',   0, ...       % _
    'viscCL_u',   0, ...       % _
    'viscCM_a',   0, ...       % _
    'viscCM_u',   0);          % _

    % Enter control inputs
        aileron = 0;
        elevator = 0;
        rudder = 0;
        controls = struct('aileron', aileron, 'elevator', elevator, 'rudder', rudder);
        

return

