% Utility to load wing geometry data from
% a space delimited text file into an
% existing AVL data structure.
% Writes AVL geometry file to boot.
load AVL_input.txt -ascii;
avldata = readavlfile('avcaaf.avl');
for i = 1:57
    avldata{4}{i+4}{2}{1} = AVL_input(i,:);
end
writeavlfile('avcaaf.avl',avldata);
