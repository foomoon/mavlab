
function[beamelements,N_beams] = beam_create(X,Y,Z,N_nodes)

%% Create beam elements along approporiate lines.  Designate X coordinates
%% of slices [51, 30, 21, 50], etc.

BeamSlice = [-12.5276,-12.0088,-11.4959,-10.9850,-10.4792,-9.9771,-9.4787,-8.9810,-8.4833,-7.9856,-7.4878,-6.9901,-6.4924,-5.9947,-5.4969,-4.9992,-4.5015,-4.0038,-3.5061,-3.0083]; 
BeamSlice = BeamSlice - .5041;   
BeamSlice = [BeamSlice,-BeamSlice];

Yslice = [-2.5233,-2.3292,-2.1894,-2.0988,-2.0530,-2.0509,-2.0892,-2.1372,-2.1853,-2.2333,-2.2813,-2.3293,-2.3773,-2.4253,-2.4734,-2.5214,-2.5694,-2.6174,-2.6654,-2.7135];
Yslice = [Yslice,Yslice];

cutoff = [-1, -.4, 0, .2, .3, .5, .5, .5, .5, .5, .5, .4, .3, .2, 0, -.2, -.4, -.9, -1.3, -1.8];
cutoff = [cutoff,cutoff];

N_Slice = length(BeamSlice);
slope = tan([85*ones(1,N_Slice/2),-85*ones(1,N_Slice/2)]*pi/180);
intercept = Yslice - (slope .* BeamSlice);

Beam1 = zeros(2,N_Slice);
Beam2 = zeros(2,N_Slice);
BeamNode = zeros(2,N_Slice);

for i = 1:N_Slice
    count = 1;
    for j = 1:N_nodes
        if abs(slope(i)*X(j) + intercept(i) - Y(j)) < .01 & Y(j) < cutoff(i)
            Beam1(count+1,i) = j;
            Beam1(1,i) = count;
            BeamY(count+1,i) = Y(j);
            BeamY(1,i) = count;
            count = count + 1;
        end
    end
end

  

toprow = Beam1(1,:);

for i = 1:N_Slice  
    A = BeamY(2:toprow(i)+1,i);
    [A,ind] = sort(A);
    A = flipud(A);
    ind = flipud(ind);
    BeamY(2:toprow(i)+1,i) = A;
    B = Beam1(2:toprow(i)+1,i);
    B = B(ind);
    Beam1(2:toprow(i)+1,i) = B;
end
 
N_beams = sum(toprow-1);
beamelements = zeros(N_beams,2);

count = 1;

for i = 1:N_Slice
    for j = 1:toprow(i)-1  
        beamelements(count,:) = [Beam1(j+1,i),Beam1(j+2,i)];
        count = count+1;
    end
end

