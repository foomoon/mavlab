%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% syntax: bool = writeavlfile(filename, avldata)
% called from: avlab.m
%
% Translates an avldata struct into an AVL compatible <filename>.avl file
% returns TRUE = 1 if successful

function bool = writeavlfile(filename, avldata)
TRUE  = 1;
FALSE = 0;

fid = fopen(filename, 'w');
if fid == -1
    disp('Err: could not open file in writeavlfile')
    bool = FALSE;
    return
end

header = avldata{1};
% write header
fprintf(fid, '%s\n', header{1});
fprintf(fid, '%f\n', header{2});
fprintf(fid, '%f %f %f\n%f %f %f\n%f %f %f\n', header{3}');
fprintf(fid, '%f\n',header{4});  
fprintf(fid, '#\n');

for i=2:1:length(avldata)
    recurseavl(avldata{i}, fid);
end % for

fprintf(fid, '#=== END AIRCRAFT ====================================\n');

bool = TRUE;
fclose(fid);
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% syntax: bool = recurseavl(cell, fid)
% called from: writeavlfile.m
%
% recurses through the avldata tree structure for writing .avl files
function bool = recurseavl(cell, fid)
TRUE = 1; FALSE = 0;

switch cell{1}
case 'MORP'
    cell
    fprintf(fid, '#\n');
    fprintf(fid, '#%s %s\n# %f %f %f %f %f %f\n', cell{1}, cell{2}, cell{3});
case 'SURF'
    fprintf(fid, '#=====================================================\n');
    fprintf(fid, '%s\n%s\n%f %f %f %f\n', cell{1}, cell{2}{1}, cell{2}{2});
    for i=3:1:length(cell)
        recurseavl(cell{i}, fid);
    end % for
case 'BODY'
    fprintf(fid, '#=====================================================\n');
    fprintf(fid, '%s\n%s\n%f %f\n', cell{1}, cell{2}{1}, cell{2}{2});
    for i=3:1:length(cell)
        recurseavl(cell{i}, fid);        
    end % for
case 'INDE'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%f\n', cell{1}, cell{2});
case 'YDUP'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%f\n', cell{1}, cell{2});
case 'SCAL'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%f %f %f\n', cell{1}, cell{2});
case 'TRAN'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%f %f %f\n', cell{1}, cell{2});
case 'ANGL'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%f\n', cell{1}, cell{2});
case 'SECT'
    fprintf(fid, '#-----------------------------------------------------\n');
    fprintf(fid, '%s\n', cell{1});
    if length(cell{2}{1}) == 5 % matlab is just wierd...
        fprintf(fid, '%f %f %f %f %f\n', cell{2}{1});
    else
        fprintf(fid, '%f %f %f %f %f %f %f\n', cell{2}{1});        
    end
    for i=3:1:length(cell)
        recurseavl(cell{i}, fid);        
    end % for
case 'NACA'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%s\n', cell{1}, cell{2});
case 'AIRF'
    fprintf(fid, '#\n');
    fprintf(fid, '%s %f %f\n', cell{1}, cell{2});
    matrix = cell{3};
    for j=1:1:size(matrix,1)
        fprintf(fid, '%f %f\n', matrix(j,:));
    end % for
case 'AFIL'
    fprintf(fid, '#\n');
    fprintf(fid, '%s', cell{1});
    if isempty(cell{2}) == FALSE
        fprintf(fid, ' %f %f', cell{2});
    end
    fprintf(fid, '\n%s\n', cell{3});
case 'DESI'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%s %f\n', cell{1}, cell{2}, cell{3});
case 'CONT'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%s %f %f %f %f %f %f\n', cell{1}, cell{2}, cell{3},...
        cell{4}, cell{5}, cell{6});
case 'CLAF'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%f\n', cell{1}, cell{2});
case 'CDCL'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%f %f %f %f %f %f\n', cell{1}, cell{2});
case 'BFIL'
    fprintf(fid, '#\n');
    fprintf(fid, '%s\n%s\n', cell{1}, cell{2});
otherwise
    fprintf(fid, '#%s, ERROR!!!\n', cell{1});
    disp('Err: unknown ID-type in writeavlfile')
end % switch

return
