
clear all
close all

load trinodes.txt -ascii
load trielements.txt -ascii

X = trinodes(:,2);
Y = trinodes(:,1);
Z = trinodes(:,3); 

N_nodes = length(X);
N_elements = length(trielements);

%% Specify AVL parameters (velocity, AOA, N_chord_panels,N_span_panels) 
velocity = 15;
AOA = 3;
N_chord_panels = 15;
N_span_panels = 60;

%% Specify torque rod construction:

torque_rod = [0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0];
torque_rod = [torque_rod,torque_rod];
%% label each node as rigid (2) or membrane (0);

type = zeros(length(trinodes),1);

for i = 1:N_elements
    if trielements(i,1) == 2
        type(trielements(i,2)) = 2;
        type(trielements(i,3)) = 2;
        type(trielements(i,4)) = 2;
    end
end

%% create beam elements

[beamelements,N_beams] = beam_create_2(X,Y,Z,N_nodes);

N_nodes0 = N_nodes;

%% create rod elements

[rodelements,N_rods,X,Y,Z,N_nodes,rod_ID] = rod_create_3(X,Y,Z,N_nodes);


tx = zeros(length(X),1);
ty = zeros(length(X),1);
W = zeros(length(X),1);

type=[type;3*ones(42,1)];

[K,bc,GlobalDOF,DOF,type] = matrix_create_3(X,Y,Z,N_nodes,N_elements,trielements,N_beams,beamelements,N_rods,rodelements,rod_ID,type,torque_rod);

%% specify number of iterations

N_t = 5;

%% specify morphing (0 is no morph, +/- 1 is full morph)

morphing = 1;

%% create a matrix to keep track of the deformation at each time step

wing_history = zeros(N_nodes,N_t);

%% create a matrix to keep track of the pressure at each time step

pressure_history = zeros(N_chord_panels*N_span_panels,N_t);

%% intitalize position vector

Dn = zeros(GlobalDOF,1);


F = sparse(zeros(GlobalDOF,1));

for i = 1:N_nodes0
      % F(DOF(i,1),1) = .005;
end  

F(DOF(2279,2),1) = .04*morphing;
F(DOF(2278,2),1) = -.04*morphing;

%% Solve Equations

Dn = solveq(K,F,bc);



for i = 1:N_t
    i
    tic
    
    count = 1;
    for j = 1:N_nodes
       wing_history(j,i) = Dn(count)*100/2.54;
       count = count + 3;
    end
    
    W = wing_history(:,i);
    
    [N_slice] = section_writer_2(X,Y,Z,W,N_nodes0);
    
    [CL(i),CD(i),roll_rate(i)] = AVL_sim(velocity,AOA,N_chord_panels,N_span_panels);
    
    roll_rate(i) = (roll_rate(i) * 2 * velocity / .7112) * 360 / 2 / pi;
    
    [dCP,Xmat,Ymat,dCPmat,dCPvect] = AVL_reader_2(X,Y,Z,N_chord_panels,N_span_panels,N_nodes0,N_nodes);
    
    pressure_history(:,i) = dCPvect;
    
     tri = trielements(:,2:4);
     subplot(3,1,1),trisurf(tri, X, Y, Z+W, W);
     title('Displacement [in]')
     xlabel('X')
     ylabel('Y')
     axis equal
     axis tight
     AXIS([-15 15 -4 4 -4 4])
     box on
     l = light('Position',[-50 -15 29]);
     view(0,90)
     lighting none
     shading interp
     colorbar('vert')

     subplot(3,1,2),surf(Xmat,Ymat,zeros(size(Xmat)),dCPmat)
     title('dCP [-]')
     xlabel('X')
     ylabel('Y')
     axis equal
     axis tight
     AXIS([-15 15 -4 4 -2 2])
     box on
     l = light('Position',[-50 -15 29]);
     view(0,90)
     lighting none
     shading interp
     colorbar('vert')
     
     subplot(3,1,3),plot([1:i],roll_rate,'ko-')
     
     Q(i) = getframe;
     
     [F] = wing_forces_2(X,Y,Z,dCP,morphing,velocity,trielements,N_elements,N_nodes,DOF,GlobalDOF);
    
     Dn = solveq(K,F,bc);
    
    toc
    
end


