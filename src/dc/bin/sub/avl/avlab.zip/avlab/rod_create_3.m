
function[rodelements,N_rods,X,Y,Z,N_nodes,rod_ID] = rod_create_3(X,Y,Z,N_nodes)

%% Create rod elements along approporiate lines.  Designate X coordinates
%% of slices [51, 30, 21, 50], etc.

RodSlice = [-12.5276,-12.0088,-11.4959,-10.9850,-10.4792,-9.9771,-9.4787,-8.9810,-8.4833,-7.9856,-7.4878,-6.9901,-6.4924,-5.9947,-5.4969,-4.9992,-4.5015,-4.0038,-3.5061,-3.0083]; 
RodSlice = RodSlice - .5041;   
RodSlice = [RodSlice,-RodSlice];

Yslice = [-2.5233,-2.3292,-2.1894,-2.0988,-2.0530,-2.0509,-2.0892,-2.1372,-2.1853,-2.2333,-2.2813,-2.3293,-2.3773,-2.4253,-2.4734,-2.5214,-2.5694,-2.6174,-2.6654,-2.7135];
Yslice = [Yslice,Yslice];

cutoff = [-1, -.4, 0, .2, .3, .5, .5, .5, .5, .5, .5, .4, .3, .2, 0, -.2, -.4, -.9, -1.3, -1.8];
cutoff = [cutoff,cutoff];

N_Slice = length(RodSlice);
slope = tan([85*ones(1,N_Slice/2),-85*ones(1,N_Slice/2)]*pi/180);
intercept = Yslice - (slope .* RodSlice);

Rod1 = zeros(2,N_Slice);
Rod2 = zeros(2,N_Slice);
RodNode = zeros(2,N_Slice);

for i = 1:N_Slice
    count = 1;
    for j = 1:N_nodes
        if abs(slope(i)*X(j) + intercept(i) - Y(j)) < .01 & Y(j) < cutoff(i)-.17
            Rod1(count+1,i) = j;
            Rod1(1,i) = count;
            RodY(count+1,i) = Y(j);
            RodY(1,i) = count;
            count = count + 1;
        end
    end
end

toprow = Rod1(1,:);

for i = 1:N_Slice  
    A = RodY(2:toprow(i)+1,i);
    [A,ind] = sort(A);
    A = flipud(A);
    ind = flipud(ind);
    RodY(2:toprow(i)+1,i) = A;
    R = Rod1(2:toprow(i)+1,i);
    R = R(ind);
    Rod1(2:toprow(i)+1,i) = R;
end

N_rods = sum(toprow-1);
rodelements = zeros(N_rods,2);

count = 1;

for i = 1:N_Slice
    for j = 1:toprow(i)-1  
        rodelements(count,:) = [Rod1(j+1,i),Rod1(j+2,i)];
        count = count+1;
    end
end


%% create the new nodes for the rod

for i = 1:N_Slice
    for j = 1:N_nodes
        if abs(slope(i)*X(j) + intercept(i) - Y(j)) < .01 & Y(j) > 1
            X_temp(i) = X(j);
            Y_temp(i) = Y(j);
            Z_temp(i) = -.47;
        end
    end
end

X_temp = [X_temp';-1.6;1.6];
Y_temp = [Y_temp';Y_temp(1);Y_temp(1)];
Z_temp = [Z_temp';-.47;-.47];

X = [X;X_temp];
Y = [Y;Y_temp];
Z = [Z;Z_temp];

N_nodes = N_nodes + length(X_temp);

%% create new elements for the rod

rodelements_temp = [[2238:2277]',Rod1(2,:)'];
rodelements_temp2 = [[2238:2256]',[2239:2257]'];
rodelements_temp3 = [[2259:2277]',[2258:2276]'];
rodelements_temp4 = [2257,2278;2279,2277];

rodelements = [rodelements;rodelements_temp;rodelements_temp2;rodelements_temp3;rodelements_temp4];
N_rods = length(rodelements);

rod_ID = 50 * ones(N_rods,1);

for i = 1:N_rods
    if Y(rodelements(i,1)) == Y(rodelements(i,2))
        rod_ID(i) = 0;
    end
end

for i = 1:N_rods
    Xm = (X(rodelements(i,1)) + X(rodelements(i,2)))/2;
    Ym = (Y(rodelements(i,1)) + Y(rodelements(i,2)))/2;
    for j = 1:N_Slice
        if abs(slope(j)*Xm + intercept(j) - Ym) < .01
            rod_ID(i) = j;
        end
    end
end

