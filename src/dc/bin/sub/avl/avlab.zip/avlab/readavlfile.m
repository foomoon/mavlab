% syntax: avldata = readavlfile(filename)
% called from: avlab.m
%
% Translates an AVL compatible .avl file to an AVLab compatible
% avldata cell.

function avldata = readavlfile(filename)

% --- avldata hierarchy ------------------------------------------
% aircraft{}
%     header{}            = ['name', 0, [3x3], Cdo]
%     surface{}
%         surfval{}       = ['id', [0, 0, 0, 0]]
%         index           = 0;
%         yduplicate      = 0;
%         scale           = [0, 0, 0];
%         translate       = [0, 0, 0];
%         angle           = 0;
%         #morph          = ['name', 0, 0, 0, 0, 0, 0, 0];
%         section{}
%             sectval     = [0, 0, 0, 0, 0, 0, 0];
%             naca        = 'airfoilname';
%             afile{}     = ['filename', 0, 0];
%             airfoil[]
%                 afrange = [0, 0];
%                 afcoord = [0, 0];
%             design{}    = ['name', 0];
%             claf        = 0;
%             cdcl        = [0, 0, 0, 0, 0, 0];
%             control{}   = ['name', 0, 0, [0, 0, 0], 0];
%     body{}
%         bfile           = 'filename';

fid   = fopen(filename, 'r');
TRUE  = 1;
FALSE = 0;

% modifying tags
NONE     = 0;
SECTION  = 1;
SURFACE  = 2;
BODY     = 3;
AIRCRAFT = 4;

if fid == -1
    disp('Err: cannot open file for readavlfile')
    avldata = -1;
    return
end

% read in header info
header{1} = fgetl(fid); % name
    [arg, txt] = getwordstr(fgetl(fid));
header{2} = str2num(arg); % Mach
txt = fgetl(fid); % symmetry
    [arg1, txt] = getwordstr(txt);
    [arg2, txt] = getwordstr(txt);
    [arg3, txt] = getwordstr(txt);
        matrix(1,:) = [str2num(arg1), str2num(arg2), str2num(arg3)];
txt = fgetl(fid); % S, C, B ref
    [arg1, txt] = getwordstr(txt);
    [arg2, txt] = getwordstr(txt);
    [arg3, txt] = getwordstr(txt);
        matrix(2,:) = [str2num(arg1), str2num(arg2), str2num(arg3)];
txt = fgetl(fid); % X, Y, Z ref
    [arg1, txt] = getwordstr(txt);
    [arg2, txt] = getwordstr(txt);
    [arg3, txt] = getwordstr(txt);
        matrix(3,:) = [str2num(arg1), str2num(arg2), str2num(arg3)];
header{3} = matrix;
    [arg, txt] = getwordstr(fgetl(fid));
header{4} = str2num(arg); % CDo

% initializing the data structure
aircraft{1} = header;
surface     = '';
body        = '';
section     = '';
modifying   = AIRCRAFT;
modval      = 0;

% file parsing
while 1 % stupid matlab
    txt = fgetl(fid);
    
    if isempty(txt)    % to avoid warnings in older Matlab versions
        continue
    end
    
    if txt == -1 % end of file
        % dont forget to save the current mod to the aircraft.
        if modifying == SECTION
            surface{size(surface, 2) + 1}   = section;   % close out the surface
            aircraft{size(aircraft, 2) + 1} = surface;   % add surface to aircraft
        elseif modifying == BODY
            aircraft{size(aircraft, 2) + 1} = body;      % add body to aircraft
        elseif modifying == SURFACE
            aircraft{size(aircraft, 2) + 1} = surface;    % add surface to aircraft
        else
            disp('Err: aircraft incomplete')
        end
        
        break
    end
    
    if length(txt) < 4  % uninteresting line, needed because later we will
        continue        % be examining the first 4 chars of each line
    end
    
    if txt(1) == '#' & txt(2:4) ~= 'MOR' % comment line
        continue
    end
    % special note: The MORPH modifier is unique to AVLab and so must appear to AVL
    % as a comment. However, to be compatible with AVLs convention on modifier names
    % the morph command is defined only by the first 4 symbols: #MOR.

    switch txt(1:4)
    case '#MOR'
        % #MORPH 'morphname'
        % # SigIn Type Gain y/c x/c Deg SgnDup
        % note: the space between '#' and 'SigIn' is very important!
        morval{1} = 'MORP'
        [void, txt] = getwordstr(txt); % filter out '#MORPH'
        [name, txt] = getwordstr(txt); % 'morphname'
        str        = fgetl(fid);
           [void, str] = getwordstr(str); % filter out '#'
           [arg1, str] = getwordstr(str); % SigIn
           [arg2, str] = getwordstr(str); % Type
           [arg3, str] = getwordstr(str); % Gain
           [arg4, str] = getwordstr(str); % y/c
           [arg5, str] = getwordstr(str); % x/c
           [arg6, str] = getwordstr(str); % Deg
        morval{2} = name;
        morval{3} = [str2num(arg1), str2num(arg2), str2num(arg3), ...
                     str2num(arg4), str2num(arg5), str2num(arg6)];
        modval = morval;
    case 'SURF' % surface{1} = {'ID', 'name', [Nchord, Cspace, Nspan, Sspace]}
        if isempty(body) == FALSE
            aircraft{size(aircraft, 2) + 1} = body;
            body = '';
        end
        if isempty(section) == FALSE
            surface{size(surface, 2) + 1} = section;
            section = '';
        end
        if isempty(surface) == FALSE
            aircraft{size(aircraft, 2) + 1} = surface;
            surface = '';
        end
        %-------------------------------
        surfval{1} = fgetl(fid);
        str        = fgetl(fid);
           [arg1, str] = getwordstr(str);
           [arg2, str] = getwordstr(str);
           [arg3, str] = getwordstr(str);
           [arg4, str] = getwordstr(str);
        surfval{2} = [str2num(arg1), str2num(arg2), str2num(arg3), str2num(arg4)];
        %-------------------------------
        surface{1} = 'SURF';
        modval     = surfval;
        modifying  = SURFACE;
    case 'BODY' % body{1} = {'ID', 'name', [Nbody, Bspace]}
        if isempty(body) == FALSE
            aircraft{size(aircraft, 2) + 1} = body;
            body = '';
        end
        if isempty(section) == FALSE
            surface{size(surface, 2) + 1} = section;
            section = '';
        end
        if isempty(surface) == FALSE
            aircraft{size(aircraft, 2) + 1} = surface;
            surface = '';
        end
        %-------------------------------
        bodyval{1} = fgetl(fid);
        str        = fgetl(fid);
            [arg1, str] = getwordstr(str);
            [arg2, str] = getwordstr(str);
        bodyval{2} = [str2num(arg1), str2num(arg2)];
        %-------------------------------
        body{1}   = 'BODY';
        modval    = bodyval;
        modifying = BODY;
    case 'INDE' % index = {'ID', Lsurf}
        indeval{1} = 'INDE';
            [arg, str] = getwordstr(fgetl(fid));
        indeval{2} = str2num(arg);
        modval = indeval;
    case 'YDUP' % yduplicate = {'ID', Ydupl}
        ydupval{1} = 'YDUP';
            [arg, str] = getwordstr(fgetl(fid));
        ydupval{2} = str2num(arg);
        modval = ydupval;
    case 'SCAL' % scale = {'ID', [Xscale, Yscale, Zscale]}
        scalval{1} = 'SCAL'
        str        = fgetl(fid);
           [arg1, str] = getwordstr(str);
           [arg2, str] = getwordstr(str);
           [arg3, str] = getwordstr(str);
        scalval{2} = [str2num(arg1), str2num(arg2), str2num(arg3)];
        modval = scalval;
    case 'TRAN' % translate = {'ID', [dX, dY, dZ]}
        tranval{1} = 'TRAN';
        str        = fgetl(fid);
           [arg1, str] = getwordstr(str);
           [arg2, str] = getwordstr(str);
           [arg3, str] = getwordstr(str);
        tranval{2} = [str2num(arg1), str2num(arg2), str2num(arg3)];
        modval = tranval;
    case 'ANGL' % angle = {'ID', dAinc}
        anglval{1} = 'ANGL';
            [arg, str] = getwordstr(fgetl(fid));
        anglval{2} = str2num(arg);
        modval = anglval;
    case 'SECT' % section{1} = {'ID', [Xle, Yle, Zle, chord, Ainc, Nspan, Sspace]}
        if isempty(section) == FALSE
            surface{size(surface, 2) + 1} = section;
            section = '';
        end
        %-------------------------------
        str        = fgetl(fid);
           [arg1, str] = getwordstr(str);
           [arg2, str] = getwordstr(str);
           [arg3, str] = getwordstr(str);
           [arg4, str] = getwordstr(str);
           [arg5, str] = getwordstr(str);
           [arg6, str] = getwordstr(str);
           [arg7, str] = getwordstr(str);
        matrix     = [str2num(arg1), str2num(arg2), str2num(arg3),...
                      str2num(arg4), str2num(arg5), str2num(arg6),...
                      str2num(arg7)];
        sectval{1} = matrix;
        %-------------------------------
        section{1} = 'SECT';
        modval     = sectval;
        modifying  = SECTION;
    case 'NACA' % naca = {'ID', nacaname}
        nacaval{1} = 'NACA';
        nacaval{2} = fgetl(fid);
        modval = nacaval;
    case 'AIRF' % airfoil = {'ID', [X1, X2], [matrix]}
        airfval{1} = 'AIRF';
        [arg, txt] = getwordstr(txt); % filter out ID-key
        [arg1, txt] = getwordstr(txt);
        [arg2, txt] = getwordstr(txt);
        airfval{2} = [str2num(arg1), str2num(arg2)];
        c = 1;
        str = fgetl(fid);
        while isletter(str(1)) == FALSE
            [arg1, str] = getwordstr(str);
            [arg2, str] = getwordstr(str);
            matrix(c) = [str2num(arg1), str2num(arg2)];
            c = c+1;
            str = fgetl(fid);
        end % while
        airfval{3} = matrix;
        modval = airfval;
    case 'CLAF' % CLaf = {'ID', CLaf}
        clafval{1} = 'CLAF';
            [arg, txt] = getwordstr(fgetl(fid));
        clafval{2} = str2num(arg);
        modval = clafval;
    case 'CDCL' % CDcl = {'ID', [CL1, CD1, CL2, CD2, CL3, CD3]}
        cdclval{1} = 'CDCL'
        str        = fgetl(fid);
           [arg1, str] = getwordstr(str);
           [arg2, str] = getwordstr(str);
           [arg3, str] = getwordstr(str);
           [arg4, str] = getwordstr(str);
           [arg5, str] = getwordstr(str);
           [arg6, str] = getwordstr(str);
        cdclval{2} = [str2num(arg1), str2num(arg2), str2num(arg3),...
                      str2num(arg4), str2num(arg5), str2num(arg6)];
        modval = cdclval;
    case 'CONT' % control = {'ID', 'name', gain, Xhinge, [x,y,zhvec], sgnDup}
        contval{1} = 'CONT';
        str        = fgetl(fid);
           [arg1, str] = getwordstr(str); contval{2} = arg1;
           [arg1, str] = getwordstr(str); contval{3} = str2num(arg1);
           [arg1, str] = getwordstr(str); contval{4} = str2num(arg1);
           
           [arg1, str] = getwordstr(str);
           [arg2, str] = getwordstr(str);
           [arg3, str] = getwordstr(str);
               contval{5} = [str2num(arg1), str2num(arg2), str2num(arg3)];
           
           [arg1, str] = getwordstr(str); contval{6} = str2num(arg1);
        modval = contval;
    case 'AFIL' % afile = {'ID', [x/c, y/c], filename}
        afilval{1}  = 'AFIL';
        [arg, txt]  = getwordstr(txt); % filter out ID-key
        [arg1, txt] = getwordstr(txt);
        [arg2, txt] = getwordstr(txt);
        afilval{2}  = [str2num(arg1), str2num(arg2)];
        afilval{3}  = fgetl(fid);
        modval      = afilval;
    case 'BFIL' % bfile = {'ID', filename}
        bfilval{1} = 'BFIL';
        bfilval{2} = fgetl(fid);
        modval     = bfilval;
    case 'DESI' % design = {'ID', 'name', weight}
        desival{1}  = 'DESI';
        [arg1, str] = getwordstr(str); desival{2} = arg1;
        [arg1, str] = getwordstr(str); desival{3} = str2num(arg1);
        modval = desival;
    otherwise
        disp('Err: unknown symbol encountered in readavlfile')
        fclose(fid);
        avldata = 0;
        return % if we dont exit here there will likely be some very messed up results
    end % switch
    
    if     modifying == SECTION
        section{size(section, 2) + 1}   = modval;
    elseif modifying == BODY
        body{size(body, 2) + 1}         = modval;
    elseif modifying == SURFACE
        surface{size(surface, 2) + 1}   = modval;
    elseif modifying == AIRCRAFT
        aircraft{size(aircraft, 2) + 1} = modval;
    else
        disp('Err: nothing being modified')
    end
    
end % while

fclose(fid);
avldata = aircraft;
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% syntax: [arg, str] = getwordstr(str)
% called from: readrunfile, readddfile, readavlfile
%
% grabs the first argument from a string and returns the what is left over

function [arg, str] = getwordstr(str)

% return two blank strings if null-length input
if length(str) == 0
    str = '';
    arg = '';
    return
end

% strip leading spaces
i=1;
while isspace(str(i)) & i < length(str)
i=i+1;
end
str = str(i:length(str));

% capture target word
i=1;
while ~isspace(str(i)) & i < length(str)
    i=i+1;
end
arg = str(1:i);

if i < length(str)
    str = str(i:length(str));
else
    str = '';
end
return
