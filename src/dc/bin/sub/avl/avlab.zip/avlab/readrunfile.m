
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% syntax: [rundatanew, inputs] = readrunfile(filename, rundataold)
% called from: avlab.m
%
% updates an avlab compatible rundata struct by importing data from
% an avl compatible .run file. It looks for the runcase specified in
% the rundataold struct so make sure you define it in rundataold
% before using this function, default runcase is 1. It reads in a file
% with the name format: <filename>.<runcase>.run, so if used in a program
% you should call writerunfile.m on the rundata to initialize a .run file
% with this naming convention. Otherwise this function will automatically
% initialize a .run file with rundataold values. Also returns a structure
% of control surface inputs.

function [rundatanew, inputs] = readrunfile(filename, rundataold)
TRUE = 1;
FALSE = 0;

fid = fopen(filename, 'r');

if fid == -1
    writerunfile(filename, rundataold, struct('NULL', 0), [0, FALSE]);
    disp('Warning: No .run file found, using defaults')
    rundatanew = rundataold;
    return
end

% skip ahead to important parts
txt = fgetl(fid);
while 1
    txt = fgetl(fid);
    if ~isempty(txt) % matlab version compatibility issues
        if txt == -1
            disp('Err: EoF reached prematurely in readrunfile')
            break % end of file
        end
    end
    
    if length(txt) < 7 % this is an uninteresting line
        continue
    end
    if txt(2:6) == 'rb/2V' 
        break
    end
    txt = fgetl(fid);
end % while

% lets extract all the possible input signals for our control surfaces
inputs = struct('NULL', 0);
while 1
    txt = fgetl(fid);
    if isempty(txt) | length(txt) < 3
        break
    end
    
    [control, txt] = getwordstr(txt); % extract name
    [void,    txt] = getwordstr(txt); % filter junk
    [void,  value] = getwordstr(txt(14:end)); % filter junk and extract value
    inputs = setfield(inputs, control, str2num(value));
end
inputs = rmfield(inputs, 'NULL'); % eliminate dummy initialization value

while 1
    txt = fgetl(fid);
    if isempty(txt)
        break
    end
    if txt == -1
        break; % end of file
    end

    % this most likely means a blank line or is otherwise meaningless
    if length(txt) < 12
        continue
    end
    
    if txt(1) == '#' | txt(1) == '!' % AVL comment lines
        continue
    end
    
    switch txt(2:12)
    case 'alpha     ='
        rundataold.alpha     = str2num(txt(13:26));
    case 'beta      ='
        rundataold.beta      = str2num(txt(13:26));
    case 'pb/2V     ='
        rundataold.pb2V      = str2num(txt(13:26));
    case 'qc/2V     ='
        rundataold.qc2V      = str2num(txt(13:26));
    case 'rb/2V     ='
        rundataold.rb2V      = str2num(txt(13:26));
    case 'CL        ='
        rundataold.CL        = str2num(txt(13:26));
    case 'CDo       ='
        rundataold.CDo       = str2num(txt(13:26));
    case 'bank      ='
        rundataold.bank      = str2num(txt(13:26));
    case 'elevation ='
        rundataold.elevation = str2num(txt(13:26));
    case 'heading   ='
        rundataold.heading   = str2num(txt(13:26));
    case 'Mach      ='
        rundataold.Mach      = str2num(txt(13:26));
    case 'velocity  ='
        rundataold.velocity  = str2num(txt(13:26));
    case 'density   ='
        rundataold.density   = str2num(txt(13:26));
    case 'grav.acc. ='
        rundataold.gravacc   = str2num(txt(13:26));
    case 'turn_rad. ='
        rundataold.turn_rad  = str2num(txt(13:26));
    case 'load_fac. ='
        rundataold.load_fac  = str2num(txt(13:26));
    case 'X_cg      ='
        rundataold.X_cg      = str2num(txt(13:26));
    case 'Y_cg      ='
        rundataold.Y_cg      = str2num(txt(13:26));
    case 'Z_cg      ='
        rundataold.Z_cg      = str2num(txt(13:26));
    case 'mass      ='
        rundataold.mass      = str2num(txt(13:26));
    case 'Ixx       ='
        rundataold.Ixx       = str2num(txt(13:26));
    case 'Iyy       ='
        rundataold.Iyy       = str2num(txt(13:26));
    case 'Izz       ='
        rundataold.Izz       = str2num(txt(13:26));
    case 'Ixy       ='
        rundataold.Ixy       = str2num(txt(13:26));
    case 'Iyz       ='
        rundataold.Iyz       = str2num(txt(13:26));
    case 'Izx       ='
        rundataold.Izx       = str2num(txt(13:26));
    case 'visc CL_a ='
        rundataold.viscCL_a  = str2num(txt(13:26));
    case 'visc CL_u ='
        rundataold.viscCL_u  = str2num(txt(13:26));
    case 'visc CM_a ='
        rundataold.viscCM_a  = str2num(txt(13:26));
    case 'visc CM_u ='
        rundataold.viscCM_u  = str2num(txt(13:26));
    case '-----------' % this indicates a new run case has been encountered
        break
    case -1 % redundant EOF break
        break
    otherwise
        disp('Err: unknown symbol encountered in readrunfile ')
    end %switch
end %while

rundatanew = rundataold;
fclose(fid);
return
