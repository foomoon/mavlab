
function[K,bc,GlobalDOF,DOF,type] = matrix_create_3(X,Y,Z,N_nodes,N_elements,trielements,N_beams,beamelements,N_rods,rodelements,rod_ID,type,torque_rod)

%% Assign DOF for each node

count = 1;

for i = 1:N_nodes
  
    DOF(i,:) = [count,count+1,count+2];
    count = count + 3;
    
end

%% Assign Nodal DOF to each triangular element

for i = 1:N_elements
    
    Edof(i,:) = [i, DOF(trielements(i,2),:),DOF(trielements(i,3),:),DOF(trielements(i,4),:)];
    
end

%% Assign Nodal DOF to each beam element

for i = 1:N_beams
    
    Edofb(i,:) = [i, DOF(beamelements(i,1),:),DOF(beamelements(i,2),:)];
    
end

%% Assign Nodal DOF to each rod element

for i = 1:N_rods
    
    Edofr(i,:) = [i, DOF(rodelements(i,1),:),DOF(rodelements(i,2),:)];
    
end

%% Find Global DOF

GlobalDOF = N_nodes*3;

K = sparse(zeros(GlobalDOF,GlobalDOF));


%% Calculate stiffness matrix for each triangle

for i = 1:N_elements
      
    X1 = X(trielements(i,2))*2.54/100;
    Y1 = Y(trielements(i,2))*2.54/100;
    Z1 = Z(trielements(i,2))*2.54/100;
  
    X2 = X(trielements(i,3))*2.54/100;
    Y2 = Y(trielements(i,3))*2.54/100;
    Z2 = Z(trielements(i,3))*2.54/100;
  
    X3 = X(trielements(i,4))*2.54/100;
    Y3 = Y(trielements(i,4))*2.54/100;
    Z3 = Z(trielements(i,4))*2.54/100;
    
    %% Label each element as membrane (0) or plate (2)
    
    element_type = trielements(i,1);
    
    T1 = zeros(3,3);
  
    T1(1,1) = (X2 - X1) / sqrt((X2 - X1)^2 + (Y2 - Y1)^2 + (Z2 - Z1)^2);
    T1(2,1) = (Y2 - Y1) / sqrt((X2 - X1)^2 + (Y2 - Y1)^2 + (Z2 - Z1)^2);
    T1(3,1) = (Z2 - Z1) / sqrt((X2 - X1)^2 + (Y2 - Y1)^2 + (Z2 - Z1)^2);
  
    dummyz = [Z1; Z2; Z3];
    dummyA = [X1, Y1, 1; X2, Y2, 1; X3, Y3, 1];
    ABC = inv(dummyA) * dummyz;
  
    T1(1,3) = -ABC(1) / sqrt(ABC(1)^2 + ABC(2)^2 + 1);
    T1(2,3) = -ABC(2) / sqrt(ABC(1)^2 + ABC(2)^2 + 1);
    T1(3,3) = 1 / sqrt(ABC(1)^2 + ABC(2)^2 + 1);
  
    T1(:,2) = cross(T1(:,3),T1(:,1));
  
    
    
    one = inv(T1) * ([X1;Y1;Z1] - [X1;Y1;Z1]);
    two = inv(T1) * ([X2;Y2;Z2] - [X1;Y1;Z1]);
    thr = inv(T1) * ([X3;Y3;Z3] - [X1;Y1;Z1]);
  
    x1 = one(1);
    y1 = one(2);
    x2 = two(1);
    y2 = two(2);
    x3 = thr(1);
    y3 = thr(2);
  
    A = polyarea([x1;x2;x3],[y1;y2;y3]);
    
    %% calculate stiffness matrix of each membrane element
    
    if element_type == 0
        
        T = 1;
        
        Bw = [Y2-Y3, Y3-Y1,Y1-Y2;X3-X2,X1-X3,X2-X1];
  
        Kw = (T/(4*A))*Bw'*Bw; 
        
        K3 = zeros(9,9);
        
        K3(1,:) = [Kw(1,1),0,0,Kw(1,2),0,0,Kw(1,3),0,0];
        K3(4,:) = [Kw(2,1),0,0,Kw(2,2),0,0,Kw(2,3),0,0];
        K3(7,:) = [Kw(3,1),0,0,Kw(3,2),0,0,Kw(3,3),0,0];
        
        K = assem(Edof(i,:),K,K3);
        
        %% calculate stiffness matrix of each plate element    
        
    elseif element_type == 2
        
        K1 = zeros(9,9); 
          
        Dp = 5*[1.2,.04,0;.04,1.2,0;0,0,.15];
          
        e_gauss = [0.5;0.5;0.0];
        n_gauss = [0.0;0.5;0.5];
        
          x23 = X2 - X3;  y23 = Y2 - Y3; 
          x31 = X3 - X1;  y31 = Y3 - Y1;
          x12 = X1 - X2;  y12 = Y1 - Y2;
  
          l23 = sqrt((x23^2 + y23^2));
          l31 = sqrt((x31^2 + y31^2));
          l12 = sqrt((x12^2 + y12^2));
  
          P4 = -6*x23/(l23^2);  P5 = -6*x31/(l31^2);  P6 = -6*x12/(l12^2); 
          q4 = 3*x23*y23/(l23^2);  q5 = 3*x31*y31/(l31^2);  q6 = 3*x12*y12/(l12^2);
          r4 = 3*y23^2/(l23^2);  r5 = 3*y31^2/(l31^2);  r6 = 3*y12^2/(l12^2);
          t4 = -6*y23/(l23^2);  t5 = -6*y31/(l31^2);  t6 = -6*y12/(l12^2);
          
          for j = 1:3
      
            e = e_gauss(j);
            n = n_gauss(j);
  
            Hxe = [P6*(1-2*e)+(P5-P6)*n; q6*(1-2*e)-(q5+q6)*n; -4+6*(e+n)+r6*(1-2*e)-n*(r5+r6); -P6*(1-2*e)+n*(P4+P6); 
                   q6*(1-2*e)-n*(q6-q4); -2+6*e+r6*(1-2*e)+n*(r4-r6); -n*(P5+P4); n*(q4-q5); -n*(r5-r4)];
            Hye = [t6*(1-2*e)+(t5-t6)*n; 1+r6*(1-2*e)-(r5+r6)*n; -q6*(1-2*e)+n*(q5+q6); -t6*(1-2*e)+n*(t4+t6); 
                   -1+r6*(1-2*e)+n*(r4-r6); -q6*(1-2*e)-n*(q4-q6); -n*(t4+t5); n*(r4-r5); -n*(q4-q5)];   
            Hxn = [-P5*(1-2*n)-e*(P6-P5); q5*(1-2*n)-e*(q5+q6); -4+6*(e+n)+r5*(1-2*n)-e*(r5+r6); e*(P4+P6); e*(q4-q6);
                   -e*(r6-r4); P5*(1-2*n)-e*(P4+P5); q5*(1-2*n)+e*(q4-q5); -2+6*n+r5*(1-2*n)+e*(r4-r5)];
            Hyn = [-t5*(1-2*n)-e*(t6-t5); 1+r5*(1-2*n)-e*(r5+r6); -q5*(1-2*n)+e*(q5+q6); e*(t4+t6); e*(r4-r6);
                   -e*(q4-q6); t5*(1-2*n)-e*(t4+t5); -1+r5*(1-2*n)+e*(r4-r5); -q5*(1-2*n)-e*(q4-q5)];  
     
            Bp = (1/(2*A))*[y31*Hxe'+y12*Hxn';-x31*Hye'-x12*Hyn';-x31*Hxe'-x12*Hxn'+y31*Hye'+y12*Hyn'];   

            K1 = 2*A*Bp'*Dp*Bp + K1;
  
           end
  
         K1 = K1/6;
                 
         K = assem(Edof(i,:),K,K1);
         
    end   

end

%% Calculate Stiffness Matrix for each beam element

  for i = 1:N_beams
    
        X1 = X(beamelements(i,1))*2.54/100;
        Y1 = Y(beamelements(i,1))*2.54/100;
        Z1 = Z(beamelements(i,1))*2.54/100;
  
        X2 = X(beamelements(i,2))*2.54/100;
        Y2 = Y(beamelements(i,2))*2.54/100;
        Z2 = Z(beamelements(i,2))*2.54/100;
        
        L = sqrt((X2-X1)^2+(Y2-Y1)^2+(Z2-Z1)^2);
        
        EI = .3*(.5E-3);
        
        a2 = EI/(L^3);

        
        K1b= zeros(6,6);
        
        K1b(1,:) = a2 * [12, -6*L, 0, -12, -6*L, 0];
        K1b(2,:) = a2 * [-6*L, 4*L^2, 0, 6*L, 2*L^2, 0];
        K1b(4,:) = a2 * [-12, 6*L, 0,12, 6*L, 0];
        K1b(5,:) = a2 * [-6*L, 2*L^2, 0, 6*L, 4*L^2, 0];
        
        K = assem(Edofb(i,:),K,K1b);

  end

%% Calculate Stiffness Matrix for each rod element

  for i = 1:N_rods
    
        X1 = X(rodelements(i,1))*2.54/100;
        Y1 = Y(rodelements(i,1))*2.54/100;
        Z1 = Z(rodelements(i,1))*2.54/100;
  
        X2 = X(rodelements(i,2))*2.54/100;
        Y2 = Y(rodelements(i,2))*2.54/100;
        Z2 = Z(rodelements(i,2))*2.54/100;
        
        L = sqrt((X2-X1)^2+(Y2-Y1)^2+(Z2-Z1)^2);
        
        K1r = zeros(6,6);
        
        if rod_ID(i) == 0
        
           EI = 1;
           a2 = EI/(L^3);
        
           GJ = .7;
           a3 = GJ/L;
           
           K1r(1,:) = a2* [12, 0, 6*L, -12, 0, 6*L];
           K1r(3,:) = a2* [6*L, 0, 4*L^2, -6*L, 0, 2*L^2];
           K1r(4,:) = a2* [-12, 0, -6*L, 12, 0, -6*L];
           K1r(6,:) = a2* [6*L, 0, 2*L^2, -6*L, 0, 4*L^2];
           
           K1r(2,:) = a3* [0,1,0,0,-1,0];
           K1r(5,:) = a3* [0,-1,0,0,1,0];
        end
        
        if rod_ID(i) ~= 0
            if torque_rod(rod_ID(i)) == 1
                EI = 1;
            else 
                EI = 1E-10;
            end
            
            a2 = EI/(L^3);
        
            K1r(1,:) = a2 * [12, -6*L, 0, -12, -6*L, 0];
            K1r(2,:) = a2 * [-6*L, 4*L^2, 0, 6*L, 2*L^2, 0];
            K1r(4,:) = a2 * [-12, 6*L, 0,12, 6*L, 0];
            K1r(5,:) = a2 * [-6*L, 2*L^2, 0, 6*L, 4*L^2, 0];

        end
    
     K = assem(Edofr(i,:),K,K1r);
        
  end

    
  


%% Set BC's

count = 1;

for i = 1:N_nodes
    
   if abs(X(i)) < 1.5
       bc(count,:) = [DOF(i,1),0];
       count = count + 1;
       bc(count,:) = [DOF(i,2),0];
       count = count + 1;
       bc(count,:) = [DOF(i,3),0];
       count = count + 1;
   end
   


end

   
 bc(count,:) = [DOF(2279,1),0];
 count = count+1;
 bc(count,:) = [DOF(2279,3),0];
 count = count+1;
 bc(count,:) = [DOF(2278,1),0];
 count = count+1;
 bc(count,:) = [DOF(2278,3),0];
 count = count+1;

bc = sort(bc);

