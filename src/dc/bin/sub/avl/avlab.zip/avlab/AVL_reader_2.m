
function[dCP,Xmat,Ymat,dCPmat,dCP_AVL] = AVL_reader_2(X,Y,Z,N_chord_panels,N_span_panels,N_nodes0,N_nodes)

force_file = textread('avcaaf_forces.txt','%s','delimiter','\n');

X_AVL = zeros(N_chord_panels*N_span_panels,1);
Y_AVL = zeros(N_chord_panels*N_span_panels,1); 
dCP_AVL = zeros(N_chord_panels*N_span_panels,1); 

row_position = 30;
count = 1;

for i = 1:N_span_panels
    for j = 1:N_chord_panels
        Q = cell2mat(force_file(row_position));
        Q(1:4) = [];
        Q = str2num(Q);
        X_AVL(count) = Q(1);
        Y_AVL(count) = Q(2);
        dCP_AVL(count) = Q(6);
        count = count+1;
        row_position = row_position+1;
    end
    row_position = row_position+11;
end
 


%% return geometry to the original configuration

X_AVL = X_AVL - 3.61868;

dum = [X_AVL,Y_AVL];
transform = [0,1;-1,0];
dum = dum*transform';
X_AVL = dum(:,1);  Y_AVL = dum(:,2);
clear dum transform

for i = 1:N_span_panels
    Xmat(:,i) = X_AVL((i-1)*N_chord_panels+1:N_chord_panels*i);
    Ymat(:,i) = Y_AVL((i-1)*N_chord_panels+1:N_chord_panels*i);
    dCPmat(:,i) = dCP_AVL((i-1)*N_chord_panels+1:N_chord_panels*i);
end

X = X(1:N_nodes0);
Y = Y(1:N_nodes0);

%% Interpolate dCP to grid

dCP = griddata(X_AVL,Y_AVL,dCP_AVL,X,Y,'nearest');

dCP = [dCP;zeros(N_nodes-N_nodes0,1)];

