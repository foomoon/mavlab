function[N_slice] = section_writer_2(X,Y,Z,W,N_nodes0);

X = X(1:N_nodes0);
Y = Y(1:N_nodes0);
Z = Z(1:N_nodes0);
W = W(1:N_nodes0);

%% rotate plane

dum = [X,Y,Z];
transform = [0,-1,0;1,0,0;0,0,1];
dum = dum*transform';
X = dum(:,1);  Y = dum(:,2);  Z = dum(:,3);
clear dum transform

%% translate plane
X = X - X(6);  Y = Y - Y(6);  Z = Z - Z(6);

%% Add displacements:

Z= Z+W;


%% Input slice planes, leading and trailing edge points

slice_data = [-13.9	-13.5	-13	-12.5	-12	-11.5	-11	-10.5	-10	-9.5	-9	-8.5	-8	-7.5	-7	-6.5	-6	-5.5	-5	-4.5	-4	-3.5	-3	-2.5	-2	-1.5	-1	-0.5	0
5.192	3.845	2.874	2.214	1.749	1.625	1.539	1.466	1.403	1.347	1.298	1.254	1.214	1.179	1.147	1.119	1.093	1.071	1.052	1.035	1.021	1.009	0.999	0.992	0.987	0.963	0.59	0.135	0
6.603	6.368	6.129	5.943	5.808	5.719	5.672	5.669	5.706	5.754	5.8	5.85	5.895	5.947	5.995	6.043	6.092	6.14	6.188	6.236	6.285	6.33	6.381	6.429	6.478	6.526	6.574	6.622	6.670];

dum = fliplr(slice_data(:,1:length(slice_data)-1));
dum(1,:) = -dum(1,:);
slice_data = [slice_data,dum];
clear dum

N_slice = length(slice_data);
N_chord = 50;

thickness_coeffs = inv([1,1,1,1;.2,.2^2,.2^3,.2^4;.3,.3^2,.3^3,.3^4;.5,.5^2,.5^3,.5^4])*[0;.9;1;.8];
unit_chord_thickness = .01;
thickness = [(0:1/(N_chord-1):1)',(0:1/(N_chord-1):1).^2',(0:1/(N_chord-1):1).^3',(0:1/(N_chord-1):1).^4']*thickness_coeffs;
thickness = thickness * unit_chord_thickness;
thickness(1) = 0;
thickness(N_chord) = 0;
thickness = flipud(thickness);

%% airfoil has the X and Zairfoil coordinates of each slice
%%AVL input has the Xle, Yle, Zle, chord, and angle of each slice

airfoil = zeros(2*N_chord-1, N_slice*2);
AVL_input = zeros(N_slice,5);

for i = 1:N_slice
    span_slice = slice_data(1,i);
    LE = slice_data(2,i);
    TE = slice_data(3,i);
    
    chord_del = (LE-TE)/(N_chord-1);
    
    X_slice = zeros(N_chord,1);
    Z_slice = zeros(N_chord,1);
    
    count = 0;
    
    for j = 1:N_chord
        X_slice(j) = TE + chord_del* count;
        count = count+1;
    end
    
    Z_slice = griddata(X,Y,Z,X_slice,span_slice*ones(size(Z_slice)),'cubic');
    
    %% the inner 7 slices need work at the trailing edge.  The following
    %% modifications are only good for N_chord = 50:
    
    if 26 <= i <= 32
        Z_slice(2) = (Z_slice(1) + Z_slice(3)) / 2;
    end
    
    %% find chord and angle:
    
    chord = sqrt((X_slice(1) - X_slice(N_chord))^2 + (Z_slice(1) - Z_slice(N_chord))^2);
    
    angle = -atan((Z_slice(1) - Z_slice(N_chord))/(X_slice(1) - X_slice(N_chord)))*180/pi;
    angle_rad = angle*pi/180;
    
    AVL_input(i,1) = X_slice(N_chord);
    AVL_input(i,2) = span_slice;
    AVL_input(i,3) = Z_slice(N_chord);
    AVL_input(i,4) = chord;
    AVL_input(i,5) = angle;
    
    %% convert the data to a unit chord
    Z_slice = (Z_slice - Z_slice(N_chord))/chord;
    X_slice = (X_slice - X_slice(N_chord))/chord;
    transform=[cos(angle_rad),-sin(angle_rad);sin(angle_rad),cos(angle_rad)];
    dummy = [X_slice,Z_slice]*transform';
    X_slice = dummy(:,1);  Z_slice = dummy(:,2);
    
    X_slice(1) = 1;   X_slice(N_chord) = 0;   Z_slice(1) = 0;   Z_slice(N_chord) = 0;  
    
    %%need to include thickness, and maybe need to swap the order of the data, double it,
    %% write to the airfoil matrix
    
    X_slice = [X_slice;flipud(X_slice(1:N_chord-1))];
    Z_slice = [Z_slice+thickness;flipud(Z_slice(1:N_chord-1))];
    
    airfoil(:,2*i-1:2*i)= [X_slice,Z_slice];

end

    
%% write each foil section

for i = 1:N_slice
    
    X_slice = airfoil(:,2*i-1);
    Z_slice = airfoil(:,2*i);
    span_slice = AVL_input(i,2);
    
    name =  mat2str(i);
    name = [name,'.dat'];
    
    slice = [X_slice,Z_slice];
    
    save(name,'slice','-ascii') 
    
end    

%% write AVL_input file

save AVL_input.txt AVL_input -ascii    

